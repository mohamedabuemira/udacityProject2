package com.example.accountingbasicsquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

import static com.example.accountingbasicsquiz.R.string.Thank_you;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
int correct_answer=0;
    private void get_correct_answer(){
        RadioButton q1 =findViewById(R.id.corectOne);
        boolean Q1=q1.isChecked();
        CheckBox q2_answer1 =findViewById(R.id.corectTwo1);
        boolean Q2_1=q2_answer1.isChecked();
        CheckBox q2_answer2 =findViewById(R.id.corectTwo2);
        boolean Q2_2=q2_answer1.isChecked();
        CheckBox q2_non =findViewById(R.id.wrongTwo);
        boolean Q2_3=q2_non.isChecked();
        RadioButton q3 =findViewById(R.id.corectThree);
        boolean Q3=q3.isChecked();
        RadioButton q4 =findViewById(R.id.corectFour);
        boolean Q4=q4.isChecked();
        RadioButton q5 =findViewById(R.id.corectFive);
        boolean Q5=q5.isChecked();
        RadioButton q6 =findViewById(R.id.corectSix);
        boolean Q6=q6.isChecked();
        if (Q1)
        {correct_answer+=1;
         }
        if (Q2_1&&Q2_2&&Q2_3==false)
        {correct_answer+=1;
        }
        if (Q3)
        {correct_answer+=1;
        }
        if (Q4)
        {correct_answer+=1;
        }
        if (Q5)
        {correct_answer+=1;
        }
        if (Q6)
        {correct_answer+=1;
        }
    }
    private void show_results_massage() {
        EditText name = findViewById(R.id.your_name);
        String user_name = name.getText().toString();
        TextView result = findViewById(R.id.results);
        String massage = getString(R.string.Results)+ "\n"  +getString(R.string.Name)+ " : "+ user_name;
        massage += "\n" + getString(R.string.Corrent_answer)+ " : " + correct_answer;
        massage += "\n" + getString(R.string.Wrong_answer) + " : "+ (6 - correct_answer);
        if(correct_answer < 3) { massage += "\n" + "Faill"; } else { massage += "\n" + "Success";};
        massage+= "\n" + getString(R.string.Thank_you);
       Toast toast = Toast.makeText(this, massage, Toast.LENGTH_SHORT);
       toast.show();
       result.setText(massage);
    }
    private void rest(){if (correct_answer<=6){correct_answer=0;return;}}
    public void submit(View view) {
        get_correct_answer();
        show_results_massage();
        rest();
    }
}
